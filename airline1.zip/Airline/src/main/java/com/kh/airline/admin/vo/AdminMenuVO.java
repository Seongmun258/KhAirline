package com.kh.airline.admin.vo;

public class AdminMenuVO {
	private String menuCode;
	private String menuName;
	private String menuSrc;
	
	public String getMenuCode() {
		return menuCode;
	}
	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuSrc() {
		return menuSrc;
	}
	public void setMenuSrc(String menuSrc) {
		this.menuSrc = menuSrc;
	}
	
	

}
