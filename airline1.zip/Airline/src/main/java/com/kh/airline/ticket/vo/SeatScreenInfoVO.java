package com.kh.airline.ticket.vo;

import java.util.List;

public class SeatScreenInfoVO {
	private int maxRowNum;
	private List<String> colCodeList;
	
	
	public int getMaxRowNum() {
		return maxRowNum;
	}
	public void setMaxRowNum(int maxRowNum) {
		this.maxRowNum = maxRowNum;
	}
	public List<String> getColCodeList() {
		return colCodeList;
	}
	public void setColCodeList(List<String> colCodeList) {
		this.colCodeList = colCodeList;
	}
	
	
	
	
	
}
