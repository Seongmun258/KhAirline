package com.kh.airline.member.vo;

public class MemberSideMenuVO {
	private String sideMenuCode;
	private String sideMenuName;
	private String sideMenuUri;
	
	public String getSideMenuCode() {
		return sideMenuCode;
	}
	public void setSideMenuCode(String sideMenuCode) {
		this.sideMenuCode = sideMenuCode;
	}
	public String getSideMenuName() {
		return sideMenuName;
	}
	public void setSideMenuName(String sideMenuName) {
		this.sideMenuName = sideMenuName;
	}
	public String getSideMenuUri() {
		return sideMenuUri;
	}
	public void setSideMenuUri(String sideMenuUri) {
		this.sideMenuUri = sideMenuUri;
	}
	
	
}
