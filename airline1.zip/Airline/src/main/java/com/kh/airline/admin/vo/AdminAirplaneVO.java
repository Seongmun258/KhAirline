package com.kh.airline.admin.vo;

public class AdminAirplaneVO {
	private String planeCode;
	private String modelCode;
	private String modelName;
	
	public String getPlaneCode() {
		return planeCode;
	}
	public void setPlaneCode(String planeCode) {
		this.planeCode = planeCode;
	}
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	

}
