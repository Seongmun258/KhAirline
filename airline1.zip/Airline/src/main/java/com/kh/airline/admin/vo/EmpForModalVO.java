package com.kh.airline.admin.vo;

import java.util.List;

public class EmpForModalVO {
	private AdminEmpVO adminEmpVO;
	//private List<E>
}
