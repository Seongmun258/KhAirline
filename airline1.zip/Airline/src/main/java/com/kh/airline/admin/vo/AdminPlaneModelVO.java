package com.kh.airline.admin.vo;

public class AdminPlaneModelVO {
	private String modelCode;
	private String modelName;
	private String maker;
	private int capacity;
	private int highestSpeed;
	
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getHighestSpeed() {
		return highestSpeed;
	}
	public void setHighestSpeed(int highestSpeed) {
		this.highestSpeed = highestSpeed;
	}

	
}
