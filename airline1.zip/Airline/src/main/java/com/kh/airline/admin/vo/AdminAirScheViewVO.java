package com.kh.airline.admin.vo;

public class AdminAirScheViewVO {
	private String airScheCode;
	private String planeCode;
	private String departureDate;
	private String departurePortCode;
	private String arrivalDate;
	private String arrivalPortCode;
	private String finalDeparturePortCode;
	private String finalDepartureDate;
	private String finalArrivalPortCode;
	private String finalArrivalDate;
	private int spareSeat;
	
	
	public String getAirScheCode() {
		return airScheCode;
	}
	public void setAirScheCode(String airScheCode) {
		this.airScheCode = airScheCode;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public String getDeparturePortCode() {
		return departurePortCode;
	}
	public void setDeparturePortCode(String departurePortCode) {
		this.departurePortCode = departurePortCode;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public String getArrivalPortCode() {
		return arrivalPortCode;
	}
	public void setArrivalPortCode(String arrivalPortCode) {
		this.arrivalPortCode = arrivalPortCode;
	}
	
	public String getFinalArrivalDate() {
		return finalArrivalDate;
	}
	public void setFinalArrivalDate(String finalArrivalDate) {
		this.finalArrivalDate = finalArrivalDate;
	}
	public String getFinalDepartureDate() {
		return finalDepartureDate;
	}
	public void setFinalDepartureDate(String finalDepartureDate) {
		this.finalDepartureDate = finalDepartureDate;
	}
	public String getPlaneCode() {
		return planeCode;
	}
	public void setPlaneCode(String planeCode) {
		this.planeCode = planeCode;
	}
	public String getFinalDeparturePortCode() {
		return finalDeparturePortCode;
	}
	public void setFinalDeparturePortCode(String finalDeparturePortCode) {
		this.finalDeparturePortCode = finalDeparturePortCode;
	}
	public String getFinalArrivalPortCode() {
		return finalArrivalPortCode;
	}
	public void setFinalArrivalPortCode(String finalArrivalPortCode) {
		this.finalArrivalPortCode = finalArrivalPortCode;
	}
	public int getSpareSeat() {
		return spareSeat;
	}
	public void setSpareSeat(int spareSeat) {
		this.spareSeat = spareSeat;
	}
	
	
	
	
}
